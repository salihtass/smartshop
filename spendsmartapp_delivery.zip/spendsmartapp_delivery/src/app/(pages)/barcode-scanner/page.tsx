"use client";

import React from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import Button from '@/components/ui/Button';
import useStore from '@/lib/store';

export default function BarcodeScannerPage() {
  const { scanBarcode, scannedProduct } = useStore();
  const [isScanning, setIsScanning] = React.useState(false);

  const handleScan = async () => {
    setIsScanning(true);
    await scanBarcode();
    setIsScanning(false);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      
      <main className="flex-grow">
        <div className="bg-blue-500 text-white p-4 mb-6">
          <h1 className="text-2xl font-bold text-center">Product Barcode Scanner</h1>
        </div>

        <div className="container mx-auto px-4">
          <div className="bg-gray-100 rounded-lg p-8 mb-6 flex flex-col items-center justify-center min-h-[400px]">
            <div className="border-2 border-dashed border-blue-400 p-16 mb-8 w-full max-w-md flex items-center justify-center">
              <p className="text-gray-600 text-center">Point camera at product barcode</p>
            </div>
            
            <Button 
              variant="primary" 
              size="lg" 
              rounded={true}
              onClick={handleScan}
              disabled={isScanning}
            >
              {isScanning ? 'Scanning...' : 'Scan Product'}
            </Button>
          </div>

          {scannedProduct && (
            <div className="mt-8">
              <h2 className="text-xl font-semibold mb-4">Scanned Product</h2>
              <div className="bg-white rounded-lg p-4 shadow-md">
                <h3 className="font-medium text-lg">{scannedProduct.name}</h3>
                {scannedProduct.price && (
                  <p className="text-gray-600">Price: €{scannedProduct.price.toFixed(2)}</p>
                )}
                {scannedProduct.category && (
                  <p className="text-blue-500">Category: {scannedProduct.category}</p>
                )}
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
