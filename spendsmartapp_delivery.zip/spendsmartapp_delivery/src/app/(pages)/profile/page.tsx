"use client";

import React from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import Switch from '@/components/ui/Switch';
import useStore from '@/lib/store';

export default function ProfilePage() {
  const { user, updateUser } = useStore();
  
  const handleNotificationToggle = (enabled: boolean) => {
    updateUser({ notificationsEnabled: enabled });
  };
  
  const handleLanguageChange = (language: 'en' | 'de') => {
    updateUser({ language });
  };
  
  const handleSpendingLimitChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value)) {
      updateUser({ dailySpendingLimit: value });
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="flex items-center mb-6">
          <button className="mr-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
          </button>
          <h1 className="text-2xl font-bold">Profile</h1>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center mb-6">
            <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mr-4">
              {user.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-xl font-semibold">{user.name}</h2>
              <p className="text-gray-600">{user.email}</p>
            </div>
          </div>
          
          <div className="border-t pt-4">
            <button className="text-blue-500 font-medium">Edit Profile</button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Settings</h2>
          
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Notifications</h3>
                <p className="text-gray-600 text-sm">Get notified about discounts</p>
              </div>
              <Switch 
                checked={user.notificationsEnabled} 
                onChange={handleNotificationToggle} 
              />
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Daily Spending Limit</h3>
              <div className="flex items-center">
                <span className="mr-2">€</span>
                <input 
                  type="number" 
                  className="border rounded-md p-2 w-full"
                  value={user.dailySpendingLimit}
                  onChange={handleSpendingLimitChange}
                  min="0"
                  step="0.01"
                />
              </div>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Language</h3>
              <div className="flex space-x-2">
                <button 
                  className={`px-4 py-2 rounded-md ${user.language === 'en' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
                  onClick={() => handleLanguageChange('en')}
                >
                  English
                </button>
                <button 
                  className={`px-4 py-2 rounded-md ${user.language === 'de' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
                  onClick={() => handleLanguageChange('de')}
                >
                  Deutsch
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4">About</h2>
          <p className="text-gray-600">SpendSmart App v1.0.0</p>
          <p className="text-gray-600">© 2025 SpendSmart</p>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
