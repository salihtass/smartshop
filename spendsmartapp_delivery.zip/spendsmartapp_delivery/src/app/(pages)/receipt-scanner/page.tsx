"use client";

import React from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import Button from '@/components/ui/Button';
import useStore from '@/lib/store';

export default function ReceiptScannerPage() {
  const { scanReceipt, scannedReceipt } = useStore();
  const [isScanning, setIsScanning] = React.useState(false);

  const handleScan = async () => {
    setIsScanning(true);
    await scanReceipt();
    setIsScanning(false);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      
      <main className="flex-grow">
        <div className="bg-blue-500 text-white p-4 mb-6">
          <h1 className="text-2xl font-bold text-center">Receipt Scanner</h1>
        </div>

        <div className="container mx-auto px-4">
          <div className="bg-gray-100 rounded-lg p-8 mb-6 flex flex-col items-center justify-center min-h-[400px]">
            <div className="border-2 border-dashed border-blue-400 p-16 mb-8 w-full max-w-md flex items-center justify-center">
              <p className="text-gray-600 text-center">Point camera at receipt</p>
            </div>
            
            <Button 
              variant="primary" 
              size="lg" 
              rounded={true}
              onClick={handleScan}
              disabled={isScanning}
            >
              {isScanning ? 'Scanning...' : 'Scan Receipt'}
            </Button>
          </div>

          {scannedReceipt && (
            <div className="mt-8">
              <h2 className="text-xl font-semibold mb-4">Scanned Receipt</h2>
              <div className="bg-white rounded-lg p-4 shadow-md">
                <p className="text-gray-600">Receipt data processed successfully!</p>
                <p className="text-blue-500 mt-2">Your spending data has been updated.</p>
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
