"use client";

import React from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import ProductCard from '@/components/features/ProductCard';
import useStore from '@/lib/store';

export default function HomePage() {
  const { topConsumedProducts, upcomingDiscounts, saveDiscount } = useStore();

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Welcome to SpendSmart</h1>
        
        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Top 5 Consumed Products</h2>
          <div className="space-y-4">
            {topConsumedProducts.map((product) => (
              <ProductCard 
                key={product.id}
                name={product.name}
                count={product.count}
              />
            ))}
          </div>
        </section>
        
        <section>
          <h2 className="text-xl font-semibold mb-4">Upcoming Discounts</h2>
          <div className="space-y-4">
            {upcomingDiscounts.map((discount) => (
              <ProductCard 
                key={discount.id}
                name={discount.name}
                store={discount.store}
                discount={discount.discount}
                expiryInfo={discount.expiryInfo}
                onSave={() => saveDiscount(discount.id)}
              />
            ))}
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
