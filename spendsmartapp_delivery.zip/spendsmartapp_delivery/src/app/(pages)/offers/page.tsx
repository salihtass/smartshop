"use client";

import React from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import SearchBar from '@/components/features/SearchBar';
import CategoryFilter from '@/components/features/CategoryFilter';
import ProductCard from '@/components/features/ProductCard';
import useStore from '@/lib/store';

export default function OffersPage() {
  const { 
    filteredOffers, 
    activeCategory, 
    setActiveCategory, 
    setSearchQuery,
    saveDiscount
  } = useStore();
  
  const categories = ['All', 'Dairy', 'Breakfast', 'Meat', 'Bakery'];
  
  // Initialize filteredOffers on component mount
  React.useEffect(() => {
    if (filteredOffers.length === 0) {
      setActiveCategory('All');
    }
  }, [filteredOffers.length, setActiveCategory]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="flex items-center mb-6">
          <button className="mr-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
          </button>
          <h1 className="text-2xl font-bold">Offers</h1>
        </div>

        <div className="mb-6">
          <SearchBar 
            placeholder="Search product..." 
            onSearch={handleSearch}
          />
        </div>

        <div className="flex justify-between mb-6">
          <div className="flex-1 mr-2">
            <button className="w-full bg-white border rounded-md p-2 flex items-center justify-between">
              <span>Filter</span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="6 9 12 15 18 9"></polyline>
              </svg>
            </button>
          </div>
          <div className="flex-1 ml-2">
            <button className="w-full bg-white border rounded-md p-2 flex items-center justify-between">
              <span>Sort</span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="6 9 12 15 18 9"></polyline>
              </svg>
            </button>
          </div>
        </div>

        <CategoryFilter 
          categories={categories}
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
        />

        <div className="space-y-4">
          {filteredOffers.length > 0 ? (
            filteredOffers.map((offer) => (
              <ProductCard 
                key={offer.id}
                name={offer.name}
                store={offer.store}
                discount={offer.discount}
                expiryInfo={offer.expiryInfo}
                onSave={() => saveDiscount(offer.id)}
              />
            ))
          ) : (
            <p className="text-center py-8 text-gray-500">No offers found matching your criteria.</p>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
